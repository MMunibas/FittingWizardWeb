#!/bin/bash

export PYTHONPATH=/usr/local/lib64/python2.7/site-packages/
export LD_LIBRARY_PATH=/usr/local/lib/

java -jar FittingWizard.jar

